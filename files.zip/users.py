"""
User API Routes
Handles user-related endpoints (authentication, profiles, etc.)
"""

from flask import Blueprint, jsonify, request

# Create Blueprint
users_bp = Blueprint('users', __name__)

@users_bp.route('/profile/<username>', methods=['GET'])
def get_user_profile(username):
    """
    GET /api/users/profile/<username>
    Get user profile information
    
    This is a placeholder - in production, you'd query a user database
    """
    try:
        # Placeholder user data
        # In production, query from database
        user_data = {
            'name': username,
            'pic': f'https://i.pravatar.cc/150?u={username}',
            'bio': 'User bio would come from database',
            'verified': True,
            'memberSince': 'January 2024',
            'responseRate': '95%'
        }
        
        return jsonify({
            'success': True,
            'data': user_data
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@users_bp.route('/contact', methods=['POST'])
def contact_user():
    """
    POST /api/users/contact
    Send a message to a user
    
    Request Body:
    - from_user: Sender name
    - to_user: Recipient name
    - message: Message content
    - apartment_id: Related apartment (optional)
    """
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['from_user', 'to_user', 'message']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        # In production, you would:
        # 1. Save message to database
        # 2. Send email notification
        # 3. Create in-app notification
        
        return jsonify({
            'success': True,
            'message': 'Message sent successfully (placeholder)',
            'data': {
                'from': data['from_user'],
                'to': data['to_user'],
                'apartment_id': data.get('apartment_id'),
                'timestamp': 'now'
            }
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500
