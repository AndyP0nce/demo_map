"""
Apartment API Routes
Handles all apartment-related endpoints
"""

from flask import Blueprint, jsonify, request
from backend.database import db
from backend.models import Apartment
from datetime import datetime

# Create Blueprint
apartments_bp = Blueprint('apartments', __name__)

@apartments_bp.route('', methods=['GET'])
def get_apartments():
    """
    GET /api/apartments
    Get all apartments or filtered apartments
    
    Query Parameters:
    - university: Filter by university ID
    - min_price: Minimum price
    - max_price: Maximum price
    - bedrooms: Number of bedrooms
    - max_distance: Maximum distance from campus
    """
    try:
        # Get query parameters
        filters = {}
        
        if request.args.get('university'):
            filters['university'] = request.args.get('university')
        
        if request.args.get('min_price'):
            filters['min_price'] = float(request.args.get('min_price'))
        
        if request.args.get('max_price'):
            filters['max_price'] = float(request.args.get('max_price'))
        
        if request.args.get('bedrooms'):
            filters['bedrooms'] = int(request.args.get('bedrooms'))
        
        if request.args.get('max_distance'):
            filters['max_distance'] = float(request.args.get('max_distance'))
        
        # Get filtered or all apartments
        if filters:
            apartments = db.filter_apartments(filters)
        else:
            apartments = db.get_all_apartments()
        
        return jsonify({
            'success': True,
            'count': len(apartments),
            'data': [apt.to_dict() for apt in apartments]
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@apartments_bp.route('/<apartment_id>', methods=['GET'])
def get_apartment(apartment_id):
    """
    GET /api/apartments/<apartment_id>
    Get a single apartment by ID
    """
    try:
        apartment = db.get_apartment_by_id(apartment_id)
        
        if not apartment:
            return jsonify({
                'success': False,
                'error': 'Apartment not found'
            }), 404
        
        return jsonify({
            'success': True,
            'data': apartment.to_dict()
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@apartments_bp.route('', methods=['POST'])
def create_apartment():
    """
    POST /api/apartments
    Create a new apartment listing
    
    Request Body: Apartment data (JSON)
    """
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['id', 'title', 'price', 'bedrooms', 'bathrooms', 
                          'sqft', 'coords', 'university', 'distance', 
                          'address', 'description']
        
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'error': f'Missing required field: {field}'
                }), 400
        
        # Check if apartment ID already exists
        if db.get_apartment_by_id(data['id']):
            return jsonify({
                'success': False,
                'error': 'Apartment ID already exists'
            }), 400
        
        # Create apartment object
        apartment = Apartment.from_dict(data)
        
        # Save to database
        created_apartment = db.create_apartment(apartment)
        
        return jsonify({
            'success': True,
            'message': 'Apartment created successfully',
            'data': created_apartment.to_dict()
        }), 201
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@apartments_bp.route('/<apartment_id>', methods=['PUT'])
def update_apartment(apartment_id):
    """
    PUT /api/apartments/<apartment_id>
    Update an existing apartment
    
    Request Body: Fields to update (JSON)
    """
    try:
        # Check if apartment exists
        apartment = db.get_apartment_by_id(apartment_id)
        if not apartment:
            return jsonify({
                'success': False,
                'error': 'Apartment not found'
            }), 404
        
        # Get update data
        data = request.get_json()
        
        # Update apartment
        updated_apartment = db.update_apartment(apartment_id, data)
        
        return jsonify({
            'success': True,
            'message': 'Apartment updated successfully',
            'data': updated_apartment.to_dict()
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@apartments_bp.route('/<apartment_id>', methods=['DELETE'])
def delete_apartment(apartment_id):
    """
    DELETE /api/apartments/<apartment_id>
    Delete an apartment listing
    """
    try:
        # Check if apartment exists
        apartment = db.get_apartment_by_id(apartment_id)
        if not apartment:
            return jsonify({
                'success': False,
                'error': 'Apartment not found'
            }), 404
        
        # Delete apartment
        success = db.delete_apartment(apartment_id)
        
        if success:
            return jsonify({
                'success': True,
                'message': 'Apartment deleted successfully'
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Failed to delete apartment'
            }), 500
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@apartments_bp.route('/nearby/<university_id>', methods=['GET'])
def get_nearby_apartments(university_id):
    """
    GET /api/apartments/nearby/<university_id>
    Get apartments near a specific university
    
    Query Parameters:
    - max_distance: Maximum distance in miles (default: 5)
    """
    try:
        max_distance = float(request.args.get('max_distance', 5))
        
        # Filter apartments
        apartments = db.filter_apartments({
            'university': university_id,
            'max_distance': max_distance
        })
        
        return jsonify({
            'success': True,
            'university': university_id,
            'max_distance': max_distance,
            'count': len(apartments),
            'data': [apt.to_dict() for apt in apartments]
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500
