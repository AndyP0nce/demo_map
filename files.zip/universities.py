"""
University API Routes
Handles all university-related endpoints
"""

from flask import Blueprint, jsonify
from backend.database import db

# Create Blueprint
universities_bp = Blueprint('universities', __name__)

@universities_bp.route('', methods=['GET'])
def get_universities():
    """
    GET /api/universities
    Get all universities
    """
    try:
        universities = db.get_all_universities()
        
        return jsonify({
            'success': True,
            'count': len(universities),
            'data': [uni.to_dict() for uni in universities]
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@universities_bp.route('/<university_id>', methods=['GET'])
def get_university(university_id):
    """
    GET /api/universities/<university_id>
    Get a single university by ID
    """
    try:
        university = db.get_university_by_id(university_id)
        
        if not university:
            return jsonify({
                'success': False,
                'error': 'University not found'
            }), 404
        
        return jsonify({
            'success': True,
            'data': university.to_dict()
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@universities_bp.route('/primary', methods=['GET'])
def get_primary_university():
    """
    GET /api/universities/primary
    Get the primary university (CSUN)
    """
    try:
        universities = db.get_all_universities()
        primary = next((uni for uni in universities if uni.is_primary), None)
        
        if not primary:
            return jsonify({
                'success': False,
                'error': 'Primary university not found'
            }), 404
        
        return jsonify({
            'success': True,
            'data': primary.to_dict()
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500
