"""
In-Memory Database - Temporary storage before connecting to real database
This simulates a database using Python dictionaries
"""

from typing import List, Optional, Dict
from backend.models import Apartment, University
import json

class InMemoryDB:
    """Simple in-memory database for development"""
    
    def __init__(self):
        self.apartments: Dict[str, Apartment] = {}
        self.universities: Dict[str, University] = {}
        self._load_initial_data()
    
    def _load_initial_data(self):
        """Load initial data from JSON-like structures"""
        # Load sample apartments
        sample_apartments = [
            {
                'id': 'apt001',
                'title': 'Cozy Studio Near CSUN',
                'price': 1200,
                'bedrooms': 0,
                'bathrooms': 1,
                'sqft': 450,
                'coords': {'lat': 34.2401, 'lng': -118.5305},
                'university': 'csun',
                'distance': 0.3,
                'images': [
                    'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800',
                    'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800',
                    'https://images.unsplash.com/photo-1484154218962-a197022b5858?w=800'
                ],
                'amenities': ['WiFi', 'Parking', 'Laundry', 'Air Conditioning'],
                'available': '2024-03-01',
                'description': 'Perfect studio for a student! Walking distance to CSUN campus. Newly renovated with modern appliances.',
                'address': '18700 Nordhoff St, Northridge, CA 91330',
                'user': {
                    'name': 'Sarah Johnson',
                    'pic': 'https://i.pravatar.cc/150?img=1',
                    'bio': 'Property manager with 5+ years experience. Quick to respond!',
                    'verified': True,
                    'memberSince': 'January 2024',
                    'responseRate': '95%'
                }
            },
            {
                'id': 'apt002',
                'title': 'Spacious 2BR Apartment',
                'price': 2100,
                'bedrooms': 2,
                'bathrooms': 2,
                'sqft': 950,
                'coords': {'lat': 34.2358, 'lng': -118.5342},
                'university': 'csun',
                'distance': 0.8,
                'images': [
                    'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800',
                    'https://images.unsplash.com/photo-1574362848149-11496d93a7c7?w=800',
                    'https://images.unsplash.com/photo-1556912173-46c336c7fd55?w=800'
                ],
                'amenities': ['WiFi', 'Parking', 'Laundry', 'Pool', 'Gym', 'Pet Friendly'],
                'available': '2024-02-15',
                'description': 'Great for roommates! Two full bathrooms, modern kitchen, and in-unit laundry. Complex has gym and pool.',
                'address': '9300 Reseda Blvd, Northridge, CA 91324',
                'user': {
                    'name': 'Michael Chen',
                    'pic': 'https://i.pravatar.cc/150?img=12',
                    'bio': 'CSUN alumni helping students find great housing. Always available to answer questions.',
                    'verified': True,
                    'memberSince': 'September 2023',
                    'responseRate': '98%'
                }
            },
            {
                'id': 'apt003',
                'title': 'Furnished 1BR with Utilities',
                'price': 1650,
                'bedrooms': 1,
                'bathrooms': 1,
                'sqft': 600,
                'coords': {'lat': 34.2425, 'lng': -118.5275},
                'university': 'csun',
                'distance': 0.5,
                'images': [
                    'https://images.unsplash.com/photo-1536376072261-38c75010e6c9?w=800',
                    'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800',
                    'https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?w=800'
                ],
                'amenities': ['WiFi', 'Parking', 'Furnished', 'Utilities Included', 'Air Conditioning'],
                'available': 'Now',
                'description': 'Move-in ready! Fully furnished with all utilities included. Perfect for international students or those with short-term needs.',
                'address': '18111 Nordhoff St, Northridge, CA 91325',
                'user': {
                    'name': 'David Martinez',
                    'pic': 'https://i.pravatar.cc/150?img=33',
                    'bio': 'Former CSUN student, now helping others. Flexible lease terms available.',
                    'verified': True,
                    'memberSince': 'March 2024',
                    'responseRate': '92%'
                }
            }
        ]
        
        # Convert to Apartment objects
        for apt_data in sample_apartments:
            apt = Apartment.from_dict(apt_data)
            self.apartments[apt.id] = apt
        
        # Load universities
        sample_universities = [
            {
                'id': 'csun',
                'name': 'CSUN',
                'fullName': 'California State University, Northridge',
                'coords': {'lat': 34.2381, 'lng': -118.5285},
                'icon': 'https://developers.google.com/maps/documentation/javascript/examples/full/images/beachflag.png',
                'isPrimary': True
            },
            {
                'id': 'ucla',
                'name': 'UCLA',
                'fullName': 'University of California, Los Angeles',
                'coords': {'lat': 34.0689, 'lng': -118.4452},
                'icon': 'https://maps.google.com/mapfiles/ms/icons/green-dot.png'
            },
            {
                'id': 'usc',
                'name': 'USC',
                'fullName': 'University of Southern California',
                'coords': {'lat': 34.0224, 'lng': -118.2851},
                'icon': 'https://maps.google.com/mapfiles/ms/icons/red-dot.png'
            }
        ]
        
        # Convert to University objects
        for uni_data in sample_universities:
            uni = University.from_dict(uni_data)
            self.universities[uni.id] = uni
    
    # Apartment CRUD operations
    def get_all_apartments(self) -> List[Apartment]:
        """Get all apartments"""
        return list(self.apartments.values())
    
    def get_apartment_by_id(self, apartment_id: str) -> Optional[Apartment]:
        """Get apartment by ID"""
        return self.apartments.get(apartment_id)
    
    def create_apartment(self, apartment: Apartment) -> Apartment:
        """Create new apartment"""
        self.apartments[apartment.id] = apartment
        return apartment
    
    def update_apartment(self, apartment_id: str, updates: Dict) -> Optional[Apartment]:
        """Update apartment"""
        apartment = self.apartments.get(apartment_id)
        if not apartment:
            return None
        
        # Update fields
        for key, value in updates.items():
            if hasattr(apartment, key):
                setattr(apartment, key, value)
        
        return apartment
    
    def delete_apartment(self, apartment_id: str) -> bool:
        """Delete apartment"""
        if apartment_id in self.apartments:
            del self.apartments[apartment_id]
            return True
        return False
    
    def filter_apartments(self, filters: Dict) -> List[Apartment]:
        """Filter apartments based on criteria"""
        results = list(self.apartments.values())
        
        # Filter by university
        if 'university' in filters:
            results = [apt for apt in results if apt.university == filters['university']]
        
        # Filter by price range
        if 'min_price' in filters:
            results = [apt for apt in results if apt.price >= filters['min_price']]
        if 'max_price' in filters:
            results = [apt for apt in results if apt.price <= filters['max_price']]
        
        # Filter by bedrooms
        if 'bedrooms' in filters:
            results = [apt for apt in results if apt.bedrooms == filters['bedrooms']]
        
        # Filter by distance
        if 'max_distance' in filters:
            results = [apt for apt in results if apt.distance <= filters['max_distance']]
        
        return results
    
    # University operations
    def get_all_universities(self) -> List[University]:
        """Get all universities"""
        return list(self.universities.values())
    
    def get_university_by_id(self, university_id: str) -> Optional[University]:
        """Get university by ID"""
        return self.universities.get(university_id)

# Global database instance
db = InMemoryDB()
