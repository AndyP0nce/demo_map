"""
SQLAlchemy Database Models
Defines the structure of MySQL tables
"""

from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, Text, ForeignKey, Table
from sqlalchemy.orm import relationship
from datetime import datetime
from backend.database.mysql_config import Base

# ============================================================================
# USER MODEL
# ============================================================================

class User(Base):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(String(50), unique=True, nullable=False, index=True)
    email = Column(String(100), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)  # Hashed password
    full_name = Column(String(100))
    phone = Column(String(20))
    profile_pic = Column(String(500))  # URL to profile picture
    bio = Column(Text)
    user_type = Column(String(20))  # 'student', 'landlord', 'both'
    verified = Column(Boolean, default=False)
    response_rate = Column(Float, default=0.0)  # Percentage
    member_since = Column(DateTime, default=datetime.utcnow)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    apartments = relationship('Apartment', back_populates='owner', cascade='all, delete-orphan')
    messages_sent = relationship('Message', foreign_keys='Message.sender_id', back_populates='sender')
    messages_received = relationship('Message', foreign_keys='Message.receiver_id', back_populates='receiver')
    favorites = relationship('Favorite', back_populates='user', cascade='all, delete-orphan')
    reviews_written = relationship('Review', foreign_keys='Review.reviewer_id', back_populates='reviewer')
    reviews_received = relationship('Review', foreign_keys='Review.reviewed_user_id', back_populates='reviewed_user')
    
    def to_dict(self):
        """Convert to dictionary for API response"""
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'full_name': self.full_name,
            'phone': self.phone,
            'profile_pic': self.profile_pic or 'https://i.pravatar.cc/150',
            'bio': self.bio,
            'user_type': self.user_type,
            'verified': self.verified,
            'response_rate': f"{self.response_rate}%",
            'member_since': self.member_since.strftime('%B %Y') if self.member_since else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
    
    def __repr__(self):
        return f"<User {self.username}>"


# ============================================================================
# UNIVERSITY MODEL
# ============================================================================

class University(Base):
    __tablename__ = 'universities'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    university_id = Column(String(50), unique=True, nullable=False, index=True)  # 'csun', 'ucla', etc.
    name = Column(String(100), nullable=False)  # 'CSUN'
    full_name = Column(String(255), nullable=False)  # 'California State University, Northridge'
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    address = Column(String(255))
    city = Column(String(100))
    state = Column(String(50))
    zip_code = Column(String(10))
    icon_url = Column(String(500))  # Map marker icon
    is_primary = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    apartments = relationship('Apartment', back_populates='university')
    
    def to_dict(self):
        """Convert to dictionary for API response"""
        return {
            'id': self.university_id,
            'name': self.name,
            'fullName': self.full_name,
            'coords': {
                'lat': self.latitude,
                'lng': self.longitude
            },
            'address': self.address,
            'city': self.city,
            'state': self.state,
            'icon': self.icon_url,
            'isPrimary': self.is_primary
        }
    
    def __repr__(self):
        return f"<University {self.name}>"


# ============================================================================
# APARTMENT MODEL
# ============================================================================

class Apartment(Base):
    __tablename__ = 'apartments'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    apartment_id = Column(String(50), unique=True, nullable=False, index=True)  # 'apt001'
    title = Column(String(200), nullable=False)
    description = Column(Text)
    price = Column(Float, nullable=False)
    bedrooms = Column(Integer, nullable=False)
    bathrooms = Column(Float, nullable=False)
    sqft = Column(Integer)
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    address = Column(String(255), nullable=False)
    city = Column(String(100))
    state = Column(String(50))
    zip_code = Column(String(10))
    
    # Foreign Keys
    university_id = Column(Integer, ForeignKey('universities.id'))
    owner_id = Column(Integer, ForeignKey('users.id'))
    
    # Additional fields
    distance_from_campus = Column(Float)  # Miles
    available_date = Column(String(50))  # 'Now', '2024-03-01', etc.
    lease_term = Column(String(100))  # 'Flexible (6-12 months)'
    utilities_included = Column(Boolean, default=False)
    furnished = Column(Boolean, default=False)
    pets_allowed = Column(Boolean, default=False)
    parking_available = Column(Boolean, default=False)
    
    # Status
    is_active = Column(Boolean, default=True)
    views_count = Column(Integer, default=0)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    university = relationship('University', back_populates='apartments')
    owner = relationship('User', back_populates='apartments')
    images = relationship('ApartmentImage', back_populates='apartment', cascade='all, delete-orphan')
    amenities = relationship('ApartmentAmenity', back_populates='apartment', cascade='all, delete-orphan')
    favorites = relationship('Favorite', back_populates='apartment', cascade='all, delete-orphan')
    reviews = relationship('Review', back_populates='apartment', cascade='all, delete-orphan')
    
    def to_dict(self, include_owner=True):
        """Convert to dictionary for API response"""
        return {
            'id': self.apartment_id,
            'title': self.title,
            'description': self.description,
            'price': self.price,
            'bedrooms': self.bedrooms,
            'bathrooms': self.bathrooms,
            'sqft': self.sqft,
            'coords': {
                'lat': self.latitude,
                'lng': self.longitude
            },
            'address': self.address,
            'city': self.city,
            'state': self.state,
            'zip_code': self.zip_code,
            'university': self.university.university_id if self.university else None,
            'distance': self.distance_from_campus,
            'available': self.available_date,
            'images': [img.image_url for img in self.images],
            'amenities': [amenity.amenity_name for amenity in self.amenities],
            'furnished': self.furnished,
            'pets_allowed': self.pets_allowed,
            'parking_available': self.parking_available,
            'utilities_included': self.utilities_included,
            'user': self.owner.to_dict() if include_owner and self.owner else None,
            'views': self.views_count,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
    
    def __repr__(self):
        return f"<Apartment {self.title}>"


# ============================================================================
# APARTMENT IMAGES MODEL
# ============================================================================

class ApartmentImage(Base):
    __tablename__ = 'apartment_images'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    apartment_id = Column(Integer, ForeignKey('apartments.id'), nullable=False)
    image_url = Column(String(500), nullable=False)
    order = Column(Integer, default=0)  # Display order
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    apartment = relationship('Apartment', back_populates='images')
    
    def __repr__(self):
        return f"<ApartmentImage {self.image_url}>"


# ============================================================================
# APARTMENT AMENITIES MODEL
# ============================================================================

class ApartmentAmenity(Base):
    __tablename__ = 'apartment_amenities'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    apartment_id = Column(Integer, ForeignKey('apartments.id'), nullable=False)
    amenity_name = Column(String(100), nullable=False)  # 'WiFi', 'Parking', etc.
    
    # Relationships
    apartment = relationship('Apartment', back_populates='amenities')
    
    def __repr__(self):
        return f"<ApartmentAmenity {self.amenity_name}>"


# ============================================================================
# FAVORITES MODEL
# ============================================================================

class Favorite(Base):
    __tablename__ = 'favorites'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    apartment_id = Column(Integer, ForeignKey('apartments.id'), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    user = relationship('User', back_populates='favorites')
    apartment = relationship('Apartment', back_populates='favorites')
    
    def __repr__(self):
        return f"<Favorite user={self.user_id} apartment={self.apartment_id}>"


# ============================================================================
# MESSAGES MODEL
# ============================================================================

class Message(Base):
    __tablename__ = 'messages'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    sender_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    receiver_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    apartment_id = Column(Integer, ForeignKey('apartments.id'))  # Optional - what it's about
    subject = Column(String(255))
    message = Column(Text, nullable=False)
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    sender = relationship('User', foreign_keys=[sender_id], back_populates='messages_sent')
    receiver = relationship('User', foreign_keys=[receiver_id], back_populates='messages_received')
    
    def to_dict(self):
        """Convert to dictionary for API response"""
        return {
            'id': self.id,
            'sender': self.sender.to_dict() if self.sender else None,
            'receiver': self.receiver.to_dict() if self.receiver else None,
            'apartment_id': self.apartment_id,
            'subject': self.subject,
            'message': self.message,
            'is_read': self.is_read,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
    
    def __repr__(self):
        return f"<Message from={self.sender_id} to={self.receiver_id}>"


# ============================================================================
# REVIEWS MODEL
# ============================================================================

class Review(Base):
    __tablename__ = 'reviews'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    reviewer_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    reviewed_user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    apartment_id = Column(Integer, ForeignKey('apartments.id'))
    rating = Column(Integer, nullable=False)  # 1-5 stars
    review_text = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    reviewer = relationship('User', foreign_keys=[reviewer_id], back_populates='reviews_written')
    reviewed_user = relationship('User', foreign_keys=[reviewed_user_id], back_populates='reviews_received')
    apartment = relationship('Apartment', back_populates='reviews')
    
    def to_dict(self):
        """Convert to dictionary for API response"""
        return {
            'id': self.id,
            'reviewer': self.reviewer.to_dict() if self.reviewer else None,
            'rating': self.rating,
            'review_text': self.review_text,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
    
    def __repr__(self):
        return f"<Review rating={self.rating}>"
