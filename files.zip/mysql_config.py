"""
MySQL Database Configuration
"""

import os
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, scoped_session
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Database connection string
# Format: mysql+pymysql://username:password@host:port/database
DATABASE_URL = os.getenv(
    'DATABASE_URL',
    'mysql+pymysql://root:password@localhost:3306/campus_apartments'
)

# Create database engine
engine = create_engine(
    DATABASE_URL,
    echo=True,  # Set to False in production (logs all SQL queries)
    pool_pre_ping=True,  # Verify connections before using
    pool_recycle=3600,  # Recycle connections after 1 hour
    pool_size=10,  # Number of connections to maintain
    max_overflow=20  # Max additional connections
)

# Create session factory
SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine
)

# Thread-safe session
Session = scoped_session(SessionLocal)

# Base class for models
Base = declarative_base()

def init_db():
    """
    Initialize database - create all tables
    Call this when app starts
    """
    Base.metadata.create_all(bind=engine)
    print("✓ Database tables created")

def get_db():
    """
    Get database session
    Use this in routes to query database
    
    Example:
        db = get_db()
        users = db.query(User).all()
        db.close()
    """
    db = Session()
    try:
        return db
    except Exception as e:
        print(f"Database connection error: {e}")
        raise

def close_db():
    """
    Close database session
    """
    Session.remove()

# Context manager for database sessions
class DatabaseSession:
    """
    Use with 'with' statement for automatic cleanup
    
    Example:
        with DatabaseSession() as db:
            users = db.query(User).all()
    """
    def __enter__(self):
        self.db = Session()
        return self.db
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            self.db.rollback()
        self.db.close()
