"""
Apartment Model - Defines the structure of apartment data
"""

from datetime import datetime
from typing import List, Dict, Optional

class Apartment:
    """Apartment data model"""
    
    def __init__(self, 
                 apartment_id: str,
                 title: str,
                 price: float,
                 bedrooms: int,
                 bathrooms: float,
                 sqft: int,
                 latitude: float,
                 longitude: float,
                 university: str,
                 distance: float,
                 images: List[str],
                 amenities: List[str],
                 available: str,
                 description: str,
                 address: str,
                 user: Dict,
                 created_at: Optional[datetime] = None):
        
        self.id = apartment_id
        self.title = title
        self.price = price
        self.bedrooms = bedrooms
        self.bathrooms = bathrooms
        self.sqft = sqft
        self.latitude = latitude
        self.longitude = longitude
        self.university = university
        self.distance = distance
        self.images = images
        self.amenities = amenities
        self.available = available
        self.description = description
        self.address = address
        self.user = user
        self.created_at = created_at or datetime.utcnow()
    
    def to_dict(self) -> Dict:
        """Convert apartment to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'title': self.title,
            'price': self.price,
            'bedrooms': self.bedrooms,
            'bathrooms': self.bathrooms,
            'sqft': self.sqft,
            'coords': {
                'lat': self.latitude,
                'lng': self.longitude
            },
            'university': self.university,
            'distance': self.distance,
            'images': self.images,
            'amenities': self.amenities,
            'available': self.available,
            'description': self.description,
            'address': self.address,
            'user': self.user,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'Apartment':
        """Create apartment from dictionary"""
        coords = data.get('coords', {})
        return cls(
            apartment_id=data.get('id'),
            title=data.get('title'),
            price=data.get('price'),
            bedrooms=data.get('bedrooms'),
            bathrooms=data.get('bathrooms'),
            sqft=data.get('sqft'),
            latitude=coords.get('lat'),
            longitude=coords.get('lng'),
            university=data.get('university'),
            distance=data.get('distance'),
            images=data.get('images', []),
            amenities=data.get('amenities', []),
            available=data.get('available'),
            description=data.get('description'),
            address=data.get('address'),
            user=data.get('user', {}),
            created_at=data.get('created_at')
        )
    
    def __repr__(self):
        return f"<Apartment {self.id}: {self.title}>"


class University:
    """University data model"""
    
    def __init__(self,
                 university_id: str,
                 name: str,
                 full_name: str,
                 latitude: float,
                 longitude: float,
                 icon: str,
                 is_primary: bool = False):
        
        self.id = university_id
        self.name = name
        self.full_name = full_name
        self.latitude = latitude
        self.longitude = longitude
        self.icon = icon
        self.is_primary = is_primary
    
    def to_dict(self) -> Dict:
        """Convert university to dictionary"""
        return {
            'id': self.id,
            'name': self.name,
            'fullName': self.full_name,
            'coords': {
                'lat': self.latitude,
                'lng': self.longitude
            },
            'icon': self.icon,
            'isPrimary': self.is_primary
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'University':
        """Create university from dictionary"""
        coords = data.get('coords', {})
        return cls(
            university_id=data.get('id'),
            name=data.get('name'),
            full_name=data.get('fullName') or data.get('full_name'),
            latitude=coords.get('lat'),
            longitude=coords.get('lng'),
            icon=data.get('icon'),
            is_primary=data.get('isPrimary', False) or data.get('is_primary', False)
        )
    
    def __repr__(self):
        return f"<University {self.id}: {self.name}>"


class User:
    """User data model"""
    
    def __init__(self,
                 name: str,
                 pic: str,
                 bio: str,
                 verified: bool = False,
                 member_since: str = None,
                 response_rate: str = None):
        
        self.name = name
        self.pic = pic
        self.bio = bio
        self.verified = verified
        self.member_since = member_since
        self.response_rate = response_rate
    
    def to_dict(self) -> Dict:
        """Convert user to dictionary"""
        return {
            'name': self.name,
            'pic': self.pic,
            'bio': self.bio,
            'verified': self.verified,
            'memberSince': self.member_since,
            'responseRate': self.response_rate
        }
    
    def __repr__(self):
        return f"<User {self.name}>"
