-- ============================================================================
-- Campus Apartments Database Schema
-- MySQL Database Creation Script
-- ============================================================================

-- Create database (if it doesn't exist)
CREATE DATABASE IF NOT EXISTS campus_apartments
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE campus_apartments;

-- ============================================================================
-- USERS TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100),
    phone VARCHAR(20),
    profile_pic VARCHAR(500),
    bio TEXT,
    user_type VARCHAR(20) DEFAULT 'student',  -- 'student', 'landlord', 'both'
    verified BOOLEAN DEFAULT FALSE,
    response_rate FLOAT DEFAULT 0.0,
    member_since DATETIME DEFAULT CURRENT_TIMESTAMP,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_username (username),
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
-- UNIVERSITIES TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS universities (
    id INT PRIMARY KEY AUTO_INCREMENT,
    university_id VARCHAR(50) UNIQUE NOT NULL,  -- 'csun', 'ucla', etc.
    name VARCHAR(100) NOT NULL,  -- 'CSUN'
    full_name VARCHAR(255) NOT NULL,  -- 'California State University, Northridge'
    latitude FLOAT NOT NULL,
    longitude FLOAT NOT NULL,
    address VARCHAR(255),
    city VARCHAR(100),
    state VARCHAR(50),
    zip_code VARCHAR(10),
    icon_url VARCHAR(500),
    is_primary BOOLEAN DEFAULT FALSE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_university_id (university_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
-- APARTMENTS TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS apartments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    apartment_id VARCHAR(50) UNIQUE NOT NULL,  -- 'apt001'
    title VARCHAR(200) NOT NULL,
    description TEXT,
    price FLOAT NOT NULL,
    bedrooms INT NOT NULL,
    bathrooms FLOAT NOT NULL,
    sqft INT,
    latitude FLOAT NOT NULL,
    longitude FLOAT NOT NULL,
    address VARCHAR(255) NOT NULL,
    city VARCHAR(100),
    state VARCHAR(50),
    zip_code VARCHAR(10),
    
    -- Foreign Keys
    university_id INT,
    owner_id INT,
    
    -- Additional fields
    distance_from_campus FLOAT,  -- Miles
    available_date VARCHAR(50),  -- 'Now', '2024-03-01', etc.
    lease_term VARCHAR(100),
    utilities_included BOOLEAN DEFAULT FALSE,
    furnished BOOLEAN DEFAULT FALSE,
    pets_allowed BOOLEAN DEFAULT FALSE,
    parking_available BOOLEAN DEFAULT FALSE,
    
    -- Status
    is_active BOOLEAN DEFAULT TRUE,
    views_count INT DEFAULT 0,
    
    -- Timestamps
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_apartment_id (apartment_id),
    INDEX idx_university_id (university_id),
    INDEX idx_owner_id (owner_id),
    INDEX idx_price (price),
    INDEX idx_is_active (is_active),
    
    FOREIGN KEY (university_id) REFERENCES universities(id) ON DELETE SET NULL,
    FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
-- APARTMENT IMAGES TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS apartment_images (
    id INT PRIMARY KEY AUTO_INCREMENT,
    apartment_id INT NOT NULL,
    image_url VARCHAR(500) NOT NULL,
    display_order INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_apartment_id (apartment_id),
    
    FOREIGN KEY (apartment_id) REFERENCES apartments(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
-- APARTMENT AMENITIES TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS apartment_amenities (
    id INT PRIMARY KEY AUTO_INCREMENT,
    apartment_id INT NOT NULL,
    amenity_name VARCHAR(100) NOT NULL,  -- 'WiFi', 'Parking', etc.
    
    INDEX idx_apartment_id (apartment_id),
    INDEX idx_amenity_name (amenity_name),
    
    FOREIGN KEY (apartment_id) REFERENCES apartments(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
-- FAVORITES TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS favorites (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    apartment_id INT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE KEY unique_favorite (user_id, apartment_id),
    INDEX idx_user_id (user_id),
    INDEX idx_apartment_id (apartment_id),
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (apartment_id) REFERENCES apartments(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
-- MESSAGES TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS messages (
    id INT PRIMARY KEY AUTO_INCREMENT,
    sender_id INT NOT NULL,
    receiver_id INT NOT NULL,
    apartment_id INT,  -- Optional - what the message is about
    subject VARCHAR(255),
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_sender_id (sender_id),
    INDEX idx_receiver_id (receiver_id),
    INDEX idx_apartment_id (apartment_id),
    INDEX idx_is_read (is_read),
    
    FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (apartment_id) REFERENCES apartments(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
-- REVIEWS TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS reviews (
    id INT PRIMARY KEY AUTO_INCREMENT,
    reviewer_id INT NOT NULL,
    reviewed_user_id INT NOT NULL,
    apartment_id INT,
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    review_text TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_reviewer_id (reviewer_id),
    INDEX idx_reviewed_user_id (reviewed_user_id),
    INDEX idx_apartment_id (apartment_id),
    INDEX idx_rating (rating),
    
    FOREIGN KEY (reviewer_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (reviewed_user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (apartment_id) REFERENCES apartments(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
-- INSERT SAMPLE DATA
-- ============================================================================

-- Insert sample universities
INSERT INTO universities (university_id, name, full_name, latitude, longitude, icon_url, is_primary) VALUES
('csun', 'CSUN', 'California State University, Northridge', 34.2381, -118.5285, 'https://developers.google.com/maps/documentation/javascript/examples/full/images/beachflag.png', TRUE),
('ucla', 'UCLA', 'University of California, Los Angeles', 34.0689, -118.4452, 'https://maps.google.com/mapfiles/ms/icons/green-dot.png', FALSE),
('usc', 'USC', 'University of Southern California', 34.0224, -118.2851, 'https://maps.google.com/mapfiles/ms/icons/red-dot.png', FALSE);

-- Insert sample user
INSERT INTO users (username, email, password_hash, full_name, phone, profile_pic, bio, user_type, verified, response_rate, member_since) VALUES
('sarah.johnson', 'sarah@example.com', 'hashed_password_here', 'Sarah Johnson', '555-0101', 'https://i.pravatar.cc/150?img=1', 'Property manager with 5+ years experience. Quick to respond!', 'landlord', TRUE, 95.0, '2024-01-01');

-- Get the IDs we just inserted
SET @csun_id = (SELECT id FROM universities WHERE university_id = 'csun');
SET @sarah_id = (SELECT id FROM users WHERE username = 'sarah.johnson');

-- Insert sample apartment
INSERT INTO apartments (apartment_id, title, description, price, bedrooms, bathrooms, sqft, latitude, longitude, address, city, state, zip_code, university_id, owner_id, distance_from_campus, available_date, furnished, pets_allowed, parking_available, is_active) VALUES
('apt001', 'Cozy Studio Near CSUN', 'Perfect studio for a student! Walking distance to CSUN campus. Newly renovated with modern appliances.', 1200, 0, 1, 450, 34.2401, -118.5305, '18700 Nordhoff St', 'Northridge', 'CA', '91330', @csun_id, @sarah_id, 0.3, 'Now', FALSE, FALSE, TRUE, TRUE);

-- Get apartment ID
SET @apt_id = (SELECT id FROM apartments WHERE apartment_id = 'apt001');

-- Insert apartment images
INSERT INTO apartment_images (apartment_id, image_url, display_order) VALUES
(@apt_id, 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800', 0),
(@apt_id, 'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800', 1),
(@apt_id, 'https://images.unsplash.com/photo-1484154218962-a197022b5858?w=800', 2);

-- Insert apartment amenities
INSERT INTO apartment_amenities (apartment_id, amenity_name) VALUES
(@apt_id, 'WiFi'),
(@apt_id, 'Parking'),
(@apt_id, 'Laundry'),
(@apt_id, 'Air Conditioning');

-- ============================================================================
-- VERIFICATION QUERIES
-- ============================================================================

-- Check what was created
SELECT 'Users:' as Info, COUNT(*) as Count FROM users
UNION ALL
SELECT 'Universities:', COUNT(*) FROM universities
UNION ALL
SELECT 'Apartments:', COUNT(*) FROM apartments
UNION ALL
SELECT 'Images:', COUNT(*) FROM apartment_images
UNION ALL
SELECT 'Amenities:', COUNT(*) FROM apartment_amenities;

-- Show sample data
SELECT 
    a.apartment_id,
    a.title,
    a.price,
    u.name as university,
    usr.username as owner
FROM apartments a
LEFT JOIN universities u ON a.university_id = u.id
LEFT JOIN users usr ON a.owner_id = usr.id;
