"""
Database package
"""

from .in_memory_db import db, InMemoryDB

__all__ = ['db', 'InMemoryDB']
